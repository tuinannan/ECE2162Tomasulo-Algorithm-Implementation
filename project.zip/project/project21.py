import string, copy, math

######notification
# VERSION 2.0 20181212
# realize pipleline with different excute cycles
# we dont use CDB buffer, if RS request CDB is not answered, it will still in RS
# we determine which data in a RS(such as Addi) by the min count flag [-1]or[-2]

    
######This is helper functions part
def helpisufunc(ins):  #decodefunc
    DEC = []
    insSp = ins.split(" ")
    insSp[0] = insSp[0].replace(".","").lower()
    DEC.append(insSp[0])
    for wd in insSp[1:]:
        num = ""
        for c in wd:
            if c.isalpha():
                DEC.append(c)
                num = ""
            elif c.isdigit() or c == "-":
                num = num + c;
            else:
                DEC.append(int(num))
                num = ""
        if num != "":
            DEC.append(int(num))
    return DEC
    
def isufunc(Storg, Funit, ISU, state, Cycles, ROB, RAT, BRP, BTB, Cdbus):
    #******prepare data of current stage
    
    PC = ISU[0]
    insMem = Storg.insMem
    addr = PC//4
    if addr < len(insMem): DEC1 = helpisufunc(insMem[addr])
    else: DEC1 = helpisufunc(insMem[-1])
   
   
    #### add by yanan##########
    
    DEC = copy.deepcopy(DEC1)

    if (DEC[0] == 'ld'):
        rename_result = RAT.readRAT(DEC[4], DEC[5])
        DEC[4] = rename_result[0]
        DEC[5] = rename_result[1]
    elif (DEC[0] == 'sd'):
        rename_result1 = RAT.readRAT(DEC[1], DEC[2])
        DEC[1] = rename_result1[0]
        DEC[2] = rename_result1[1]
        rename_result2 = RAT.readRAT(DEC[4], DEC[5])
        DEC[4] = rename_result2[0]
        DEC[5] = rename_result2[1]
    elif (DEC[0] == 'addi'):
        rename_result = RAT.readRAT(DEC[3], DEC[4])
        DEC[3] = rename_result[0]
        DEC[4] = rename_result[1]
    elif (DEC[0] == 'bne' or DEC[0] =='beq'):

        if type(DEC[3]) != int:
            rename_result1 = RAT.readRAT(DEC[1], DEC[2])
            rename_result2 = RAT.readRAT(DEC[3], DEC[4])
            DEC[1] = rename_result1[0]
            DEC[2] = rename_result1[1]
            DEC[3] = rename_result2[0]
            DEC[4] = rename_result2[1]
        else:
            rename_result = RAT.readRAT(DEC[1], DEC[2])
            DEC[1] = rename_result[0]
            DEC[2] = rename_result[1]
    
    else:
        rename_result1 = RAT.readRAT(DEC[3], DEC[4])
        DEC[3] = rename_result1[0]
        DEC[4] = rename_result1[1]
        rename_result2 = RAT.readRAT(DEC[5], DEC[6])
        DEC[5] = rename_result2[0]
        DEC[6] = rename_result2[1]
    
      


    ########by yanan########    

    allolst = ["empty"] * 6
    allolst[0] = DEC[0]
    allolst[5] = PC

    if allolst[0] == "add" or allolst[0] == "sub":
        allolst[1] = DEC[2]
        allolst[4] = DEC[2]
        if DEC[3] == 'ROB':
            allolst[2] = str('ROB' + str(DEC[4]))
            if ROB.ROB[DEC[4]][3] == True:
                allolst[2] = ROB.ROB[DEC[4]][2]
        else:
            allolst[2] = Storg.inRReg[DEC[4]]
        
        if DEC[5] == 'ROB':
            allolst[3] = str('ROB' + str(DEC[6]))
            if ROB.ROB[DEC[6]][3] == True:
                allolst[3] = ROB.ROB[DEC[6]][2]
        else:
            allolst[3] = Storg.inRReg[DEC[6]]

    elif allolst[0] == "addi":
        allolst[1] = DEC[2]
        allolst[4] = DEC[2]
        if DEC[3] == 'ROB':
            allolst[2] = str('ROB' + str(DEC[4]))
            if ROB.ROB[DEC[4]][0] == True:
                allolst[2] = ROB.ROB[DEC[4]][2]
        else:
            allolst[2] = Storg.inRReg[DEC[4]]
        allolst[3] = DEC[5]
            
    elif allolst[0] == "addd" or allolst[0] == "subd" or allolst[0] == "mult":

        allolst[1] = DEC[2]
        allolst[4] = DEC[2]
        if DEC[3] == 'ROB':
            allolst[2] = str('ROB' + str(DEC[4]))
            if ROB.ROB[DEC[4]][3] == True:
                allolst[2] = ROB.ROB[DEC[4]][2]
        else:
            allolst[2] = Storg.flFReg[DEC[4]]
        if DEC[5] == 'ROB':
            allolst[3] = str('ROB' + str(DEC[6]))
            if ROB.ROB[DEC[6]][3] == True:
                allolst[3] = ROB.ROB[DEC[6]][2]
        else:
            allolst[3] = Storg.flFReg[DEC[6]]
    
    elif allolst[0] == "ld":
        allolst[1] = DEC[2]
        allolst[4] = DEC[2]
        #if type(DEC[3]) == int:
        allolst[3] = DEC[3]
        if DEC[4] == 'ROB':
            allolst[2] = str('ROB' + str(DEC[5]))
            if ROB.ROB[DEC[5]][3] == True:
                allolst[2] = ROB.ROB[DEC[5]][2]
        else:
            allolst[2] = Storg.inRReg[DEC[5]]
        #    allolst[1:4] = [DEC[2], Storg.inRReg[DEC[5]], DEC[3]]
        # else:
        #    allolst[1:4] = [DEC[2], Storg.inRReg[DEC[4]], 0] 

    elif allolst[0] == "sd":
        
        allolst[3] = DEC[3]
        if DEC[1] == 'ROB':
            allolst[1] = str('ROB' + str(DEC[2]))
            if ROB.ROB[DEC[2]][3] == True:
                allolst[1] = ROB.ROB[DEC[2]][2]
        else:
            allolst[1] = Storg.flFReg[DEC[2]]
        if DEC[4] == 'ROB':
            allolst[2] = str('ROB' + str(DEC[5]))
            if ROB.ROB[DEC[5]][3] == True:
                allolst[2] = ROB.ROB[DEC[5]][2]
        else:
            allolst[2] = Storg.inRReg[DEC[5]]
        
    else:##branch instruction
        if DEC[1] == 'ROB':
            allolst[2] = str('ROB' + str(DEC[2]))
            if ROB.ROB[DEC[2]][3] == True:
                allolst[2] = ROB.ROB[DEC[2]][2]
        elif DEC[1] == 'F':
            allolst[2] = Storg.flFReg[DEC[2]]
        else:
            allolst[2] = Storg.inRReg[DEC[2]]
       
        if type(DEC[3]) != int :
            if DEC[3] == 'ROB' :
                allolst[3] = str('ROB' + str(DEC[4]))
                if ROB.ROB[DEC[4]][3] == True:
                    allolst[3] = ROB.ROB[DEC[4]][2]
            elif DEC[3] == 'F':
                allolst[3] = Storg.flFReg[DEC[4]]
            else:
                allolst[3] = Storg.inRReg[DEC[4]]
            allolst[1] = DEC[5]
        else:
            allolst[3] = DEC[3]
            allolst[1] = DEC[4]
        
    #search brp and btb structrue####
    if (allolst[0] != 'bne' and allolst[0] != 'beq'):
        if Funit.allocate(allolst, check = True): 
            
            PC = PC + 4 #PC+4 when allocable
            ROB_Index = ROB.addROB(str(DEC[1] + str(DEC[2])), DEC[0], allolst[5])
            if(DEC[0] != 'sd'):
                allolst[1] = ROB_Index
                RAT.updateRAT(DEC[1], DEC[2], ['ROB', ROB_Index])
                allolst[4] = ROB_Index
            else:
                allolst[4] = ROB_Index
                
            allores = Funit.allocate(allolst)
            if allores != False: Cdbus.announcelst.append(allores)

        else:
            allolst = ['empty']
    else:
        jump = BRP.searchBRP((PC//4)%8)
        if jump == 0:
            if Funit.allocate(allolst, check = True): 
                ROB_Index = ROB.addROB(str(DEC[1] + str(DEC[2])), DEC[0], allolst[5])
                allolst[4] = ROB_Index
                PC = PC + 4
                jump_address = 0
                ROB.updateROB_branch(ROB_Index, jump, jump_address)
                RAT.copyRAT(ROB_Index)
                allores = Funit.allocate(allolst)
                if allores != False: Cdbus.announcelst.append(allores)
                print("go here once 1")
            else:
                allolst = ['empty']
        else:
            if Funit.allocate(allolst, check = True): 
                ROB_Index = ROB.addROB(str(DEC[1] +str(DEC[2])), DEC[0], allolst[5])
                allolst[4] = ROB_Index
                jump_address = BTB.searchBTB((PC//4)%8)
                print(jump_address,"@@@@@@@")
                PC = PC + 4 + jump_address * 4
                ROB.updateROB_branch(ROB_Index, jump, jump_address)
                RAT.copyRAT(ROB_Index)
                allores = Funit.allocate(allolst)
                if allores != False: Cdbus.announcelst.append(allores)
                print("go here once 2")
            else:
                allolst = ['empty']


    #******generate data of next stage
    ISUNXT = [PC] + allolst
    
    #******Cycles table
    if Cycles.sel == 1:
        if allolst[0] != 'empty':
            addr = allolst[-1]//4
            Cycles.ctabl[addr][0] = str(Cycles.clock)
            Cycles.ctabl[addr][1] = str(Cycles.clock + 1)
    else:
        if allolst[0] != 'empty':
            addr = allolst[-1]//4
            if addr < len(Storg.insMem):
                Cycles.insMem2.append(Storg.insMem[addr])
        if allolst[0] != 'empty':
            addr = allolst[-2]
            Cycles.ctabl2[addr][0] = str(Cycles.clock)
            Cycles.ctabl2[addr][1] = str(Cycles.clock + 1)       
    return ISUNXT
    
def exufunc(Storg, Funit, Cdbus, EXU, state, Cycles, ROB, RAT, BRP, BTB, LSQ):
    #******main function of current stage
    Funit.PC_next = EXU[0]
    allolst = EXU[1:]

    requestlstTmp = copy.deepcopy(Cdbus.requestlst)
    requestlstCal = Funit.calculat(ROB, RAT, BRP, BTB, LSQ, Storg, Cdbus)

    for i in range(len(requestlstTmp)): #may be unuseful
        if requestlstTmp[i] == False: Cdbus.requestlst[i] = requestlstCal[i]
    

    PC = Funit.PC_next
    #******generate data of next stage
    
    busdata = Cdbus.arbit()
    Funit.clear(busdata, LSQ)
    
    EXUNXT = copy.deepcopy([PC, busdata])
    Cdbus.clear()
    
    #******Cycles table
    if Cycles.sel == 1:
        addr = busdata[0].split(' ')[-1]
        if addr != 'empty':
            addr = int(addr)//4
            if 'dqu' in busdata[0]:
                tmp = int(Cycles.ctabl[addr][1].split('-')[-1])
                if Cycles.clock != tmp:
                    Cycles.ctabl[addr][2] = str(tmp + 1) + '-' + str(Cycles.clock)
            else:
                if '-' in Cycles.ctabl[addr][1]: Cycles.ctabl[addr][1] = Cycles.ctabl[addr][1].split('-')[0]
                Cycles.ctabl[addr][1] += "-" + str(Cycles.clock)
                Cycles.ctabl[addr][2] = '-'
        if Funit.flag_br != []:
            addr = int(Funit.flag_br[1][0].split(' ')[-1])//4
            if '-' in Cycles.ctabl[addr][1]: Cycles.ctabl[addr][1] = Cycles.ctabl[addr][1].split('-')[0]
            Cycles.ctabl[addr][1] += "-" + str(Cycles.clock)
            Funit.flag_br = []
        if Funit.flag_lsq != []:
            addr = int(Funit.flag_lsq[1][0].split(' ')[-1])//4
            if '-' in Cycles.ctabl[addr][1]: Cycles.ctabl[addr][1] = Cycles.ctabl[addr][1].split('-')[0]
            Cycles.ctabl[addr][1] += "-" + str(Cycles.clock + 1)
            Funit.flag_lsq = []
    else:
        if busdata[0].split(' ')[-1] != 'empty':
            addr = busdata[0].split(' ')[-2]
            addr = int(addr)
            if 'dqu' in busdata[0]:
                tmp = int(Cycles.ctabl2[addr][1].split('-')[-1])
                if Cycles.clock != tmp:
                    Cycles.ctabl2[addr][2] = str(tmp + 1) + '-' + str(Cycles.clock)
            else:
                if '-' in Cycles.ctabl2[addr][1]: Cycles.ctabl2[addr][1] = Cycles.ctabl2[addr][1].split('-')[0]
                Cycles.ctabl2[addr][1] += "-" + str(Cycles.clock)
                Cycles.ctabl2[addr][2] = '-'
        if Funit.flag_br != []:
            addr = int(Funit.flag_br[1][0].split(' ')[-2])
            if '-' in Cycles.ctabl2[addr][1]: Cycles.ctabl2[addr][1] = Cycles.ctabl2[addr][1].split('-')[0]
            Cycles.ctabl2[addr][1] += "-" + str(Cycles.clock)
            Funit.flag_br = []
        if Funit.flag_lsq != []:
            addr = int(Funit.flag_lsq[1][0].split(' ')[-2])
            if '-' in Cycles.ctabl2[addr][1]: Cycles.ctabl2[addr][1] = Cycles.ctabl2[addr][1].split('-')[0]
            Cycles.ctabl2[addr][1] += "-" + str(Cycles.clock + 1)
            Funit.flag_lsq = []       
    return EXUNXT
    
    
def memfunc(Storg, Cdbus, MEM, state, Cycles, LSQ, ROB):
    #******main function of current stage
    flag1 = copy.deepcopy(MEM[1])
    flag2 = str(flag1).replace('[\'','')
    flag2 = str(flag2).replace('\']', '')
    flag3 = flag2.split()
    return_value = LSQ.exeLSQ()    
    if 'ldqu'in flag3[0] or 'sdqu' in flag3[0]:
        ROB_Index = flag3[3]
        PC_current = flag3[4]
        destination = flag3[1]
        address = flag3[2]
        op_type = flag3[0]
        
        LSQ.addLSQ(destination, address, op_type, PC_current, ROB_Index, ROB, Funit.memcyc)

        if return_value != False :
            MEMNXT = [MEM[0]] + return_value
            return MEMNXT
        else:
            return ([MEM[0]] + ['empty'] + ['empty'])
    return ([MEM[0]] + ['empty'] + ['empty'])
    
def helpwbkfunc(searchitem, Funit, res):
    for item in Funit.addi:
        if (searchitem) in item:
            item[item.index(searchitem)] = int(res)
        if (searchitem) in item:
            item[item.index(searchitem)] = int(res)
    for item in Funit.addd:
        if (searchitem) in item:
            item[item.index(searchitem)] = float(res)
        if (searchitem) in item:
            item[item.index(searchitem)] = float(res)
    for item in Funit.mult:
        if (searchitem) in item:
            item[item.index(searchitem)] = float(res)
        if (searchitem) in item:
            item[item.index(searchitem)] = float(res)
    for item in Funit.lsqu:
        if (searchitem) in item:
            item[item.index(searchitem)] = float(res)
        if (searchitem) in item:
            item[item.index(searchitem)] = float(res)     
def wbkfunc(Storg, Cdbus, WBK, state, Cycles, ROB, Funit): #xin2
    #******main function of current stage
    print(WBK, "####writeback####")
    
    #******Cycles table
    if Cycles.sel == 1:
        if WBK[1][0] != 'empty':
            addr = WBK[1][0].split(' ')[-1]
            addr = int(addr)//4
            Cycles.ctabl[addr][3] = str(Cycles.clock)
    else:
        if WBK[1][0] != 'empty':
            addr = WBK[1][0].split(' ')[-2]
            addr = int(addr)
            Cycles.ctabl2[addr][3] = str(Cycles.clock)


    if type(WBK[1]) == list and type(WBK[1][0]) == str:
        WBKNXTa = []
        for item in WBK[1]:
            WBKsp = item.split(" ")

            if "addi" in WBKsp[0]:
                ROB.updateROB(int(WBKsp[3]), int(WBKsp[2]))
                helpwbkfunc("ROB"+WBKsp[3], Funit, WBKsp[2])
            if "addd" in WBKsp[0]:
                ROB.updateROB(int(WBKsp[3]), float(WBKsp[2]))
                helpwbkfunc("ROB"+WBKsp[3], Funit, WBKsp[2])
            if "mult" in WBKsp[0]:
                ROB.updateROB(int(WBKsp[3]), float(WBKsp[2]))
                helpwbkfunc("ROB"+WBKsp[3], Funit, WBKsp[2])
            if "dqu" in WBKsp[0]:
                ROB.updateROB(int(WBKsp[3]), float(WBKsp[2]))
                helpwbkfunc("ROB"+WBKsp[3], Funit, WBKsp[2])
    else:
        WBKNXTa = copy.deepcopy(WBK[1:])

    #******generate data of next stage
    PC = WBK[0]
    if WBK[1] == 0: WBK[1] = ["empty"]
    WBKNXT = [PC, WBKNXTa]

    
def cmtfunc(Storg, Cdbus, Funit, state, Cycles, ROB, LSQ):
    #******
    PC, ROBindex  =  ROB.commitROB(Storg, LSQ, Funit.memcyc)
    print(PC, "commit PC index")
    
    #******Cycles table  
    if Cycles.sel == 1:
        if str(PC) != 'False':
            addr = int(PC)//4
            Cycles.ctabl[addr][4] = str(Cycles.clock)
    else:
        if str(ROBindex) != 'False':
            addr = int(ROBindex-1)
            Cycles.ctabl2[addr][4] = str(Cycles.clock)
    return PC
    

######This is Class
class STstruct(object): #all kinds of storage
    def __init__(self, insMem, inRinit, flFinit, Meminit):
        self.insMem = insMem    
        self.inRReg = [0] * 32
        self.flFReg = [0] * 32
        self.mainMem = [0] * 256
        for i in range(0, len(inRinit), 2):
            self.inRReg[inRinit[i]] = inRinit[i+1]
        for i in range(0, len(flFinit), 2):
            self.flFReg[flFinit[i]] = flFinit[i+1] 
        for i in range(0, len(Meminit), 2):
            self.mainMem[Meminit[i]] = Meminit[i+1]              
        
class FUstruct(object): # all kinds of function units
    def __init__(self, addi, addd, mult, lsqu, caddi, caddd, cmult, clsqu, memcyc):
        self.addi = [([False] + ["empty"] * 7) for row in range(addi)]
        self.addd = [([False] + ["empty"] * 7) for row in range(addd)]
        self.mult = [([False] + ["empty"] * 7) for row in range(mult)]
        self.lsqu = [([False] + ["empty"] * 7) for row in range(lsqu)]
        self.PC_next = 0
        self.mis_pre = 0
        self.flag_br = []
        self.flag_lsq = [] 

        (self.cai, self.cad, self.cmt, self.clu) = (caddi, caddd, cmult, clsqu)
        self.memcyc = memcyc
    def __repr__(self):
        allFU = "addi is:" + str(self.addi) + "\n" + \
                "addd is:" + str(self.addd) + "\n" + \
                "mult is:" + str(self.mult) + "\n" + \
                "lsqu is:" + str(self.lsqu) + "\n"
        return allFU
    @staticmethod
    def helpallocate(rslst, rscyc, allolst, type, check):
        for item in rslst:
            if item[0] == False:
                if check: return True  #if check is True, just check if RS is allocatable, not allocate
                item[0] = True
                item[1:] = copy.deepcopy(allolst)
                item.append(rscyc)
                if type == "ldqu" or type == "sdqu": item.append(type)
                
                return type + str(rslst.index(item))
        return False
    def allocate(self, allolst, check=False):
        if allolst[0] == "add":    
            return self.helpallocate(self.addi,self.cai, allolst, "addi", check)
        elif allolst[0] == "addi": 
            return self.helpallocate(self.addi,self.cai, allolst, "addi", check)
        elif allolst[0] == "bne":   
            return self.helpallocate(self.addi, 2, allolst, "bne", check)
        elif allolst[0] == "beq":   
            return self.helpallocate(self.addi, 2, allolst, "beq", check)
        elif allolst[0] == "addd": 
            return self.helpallocate(self.addd,self.cad, allolst, "addd", check)
        elif allolst[0] == "sub":  
            return self.helpallocate(self.addi,self.cai, allolst, "addi", check)
        elif allolst[0] == "subd": 
            return self.helpallocate(self.addd,self.cad, allolst, "addd", check)
        elif allolst[0] == "mult": 
            return self.helpallocate(self.mult,self.cmt, allolst, "mult", check)
        elif allolst[0] == "ld":   
            return self.helpallocate(self.lsqu,self.clu, allolst, "ldqu", check)
        elif allolst[0] == "sd":   
            return self.helpallocate(self.lsqu,self.clu, allolst, "sdqu", check)
        else: return False
    
    def helpcalculatAddi(self, rslst, ROB, RAT, BRP, BTB, LSQ, Cdbus):
        flg = False
        for item in rslst:
            if (not isinstance(item[3],str)) and (not isinstance(item[4],str)):
                if "bne" in item[1] or "beq" in item[1]:
                    mis = self.misprediction_check(item[1], item[2], item[3]-item[4], item[5], ROB, RAT, BRP, BTB, item[6], LSQ, Cdbus)
                    if mis != 1:
                        if item[-1] == 2:
                            item[-1] = item[-1] - 1
                item[-1] -= 1
        N1lst = [str(N1item[-1]) for N1item in rslst]
        #if min(N1lst) != max(N1lst):
        N1index = N1lst.index(min(N1lst))
        if min(N1lst) == max(N1lst):
            if "bne" in rslst[N1index][1] or "beq" in rslst[N1index][1]:
                print("go ahead")
            else:
                N1index = 1 - N1index
        if rslst[N1index][-1] != "empty" and rslst[N1index][-1] <= 0:
            if rslst[N1index][1] == "add" or rslst[N1index][1] == "addi":
                res = rslst[N1index][3] + rslst[N1index][4]; flg = True;
                type = "addi";
            if rslst[N1index][1] == "sub":
                res = rslst[N1index][3] - rslst[N1index][4]; flg = True;
                type = "addi";
            if rslst[N1index][1] == "bne":
                res = rslst[N1index][3] - rslst[N1index][4]; flg = True;
                type = "bne";
            if rslst[N1index][1] == "beq":
                res = rslst[N1index][3] - rslst[N1index][4]; flg = True;  
                type = "beq";          
           
            index = N1index; des = rslst[N1index][2];
            robindex = rslst[N1index][5]; PC = rslst[N1index][6]
                

        if flg:
            if type == 'bne' or type == 'beq':
                PC =  self.misprediction(type, des, res, robindex, ROB, RAT, BRP, BTB, PC, LSQ, Cdbus)
                self.addi[N1index] = [False] + ["empty"] * 8
                self.flag_br = self.flag_br + [1, [type + str(index) + " " +
                    str(des) + " " + str(res) + " " + str(robindex) + " " + str(PC)]]
                return False
        if flg: return type + str(index) + " " + str(des) + " " + str(res) + \
                        " " + str(robindex) + " " + str(PC)
        else:
            return False
            
    @staticmethod
    def helpcalculatAddd(rslst):
        flg = False
        for item in rslst:
            if (not isinstance(item[3],str)) and (not isinstance(item[4],str)):
                item[-1] -= 1
        N1lst = [str(N1item[-1]) for N1item in rslst]
        N1index = N1lst.index(min(N1lst))
        if rslst[N1index][-1] != "empty" and rslst[N1index][-1] <= 0:
            if rslst[N1index][1] == "addd":
                res = rslst[N1index][3] + rslst[N1index][4]; flg = True;
            if rslst[N1index][1] == "subd":
                res = rslst[N1index][3] - rslst[N1index][4]; flg = True;
            index = N1index; des = rslst[N1index][2];
            robindex = rslst[N1index][5]; PC = rslst[N1index][6]
            # res = round(res, 2)
        if flg: return "addd" + str(index) + " " + str(des) + " " + str(res) + \
                        " " + str(robindex) + " " + str(PC)
        else: return False
    @staticmethod
    def helpcalculatMult(rslst):
        flg = False
        for item in rslst:
            if (not isinstance(item[3],str)) and (not isinstance(item[4],str)):
                # if 'mult' in item[1] and 'ROB' in str(item[2]): continue
                item[-1] -= 1
        N1lst = [str(N1item[-1]) for N1item in rslst]
        N1index = N1lst.index(min(N1lst))
        if rslst[N1index][-1] != "empty" and rslst[N1index][-1] <= 0:
            # print(rslst)
            res = rslst[N1index][3] * rslst[N1index][4]; flg = True;
            index = N1index; des = rslst[N1index][2];
            robindex = rslst[N1index][5]; PC = rslst[N1index][6]
        if flg: 
            # res = round(res, 2)
            return "mult" + str(index) + " " + str(des) + " " + str(res) + \
                        " " + str(robindex) + " " + str(PC)
        else: return False
    
    def helpcalculatLsqu(self, rslst, LSQ, Storg, ROB): #ld, 1, 2, 4 => ld F1 R2 offset4
        flg = False
        for item in rslst:
            if (not isinstance(item[3],str)) and (not isinstance(item[4],str)):
                if 'sd' in item[1] and 'ROB' in str(item[2]): continue
                item[-2] -= 1
                if item[-2] == 0:
                    item_index = rslst.index(item)
                    res = item[3] + item[4]
                    LSQ.addLSQ((item[2]), res, (str(item[8]) + str(item_index)), item[6], item[5], ROB, self.memcyc)
                    self.flag_lsq = self.flag_lsq + [1, [str(item[8]) + " " + str(item[5]) + " " + str(item[3]) + " " + str(item[5]) + " " + str(item[6])]]
        return_value = LSQ.exeLSQ(Storg)
        for item1 in LSQ.LSQ:
            if item1[0] == False and item1[1] == True and item1[6] == True:
                item1[6] = False
                for item2 in self.lsqu:
                    if item2[0] != False:
                        if item2[5] == item1[9]:
                            index= self.lsqu.index(item2)
                            self.lsqu[index] = [False] + ["empty"] * 7

        if return_value != False :
            return return_value

        else :
            return False
 
    
    def calculat(self, ROB, RAT, BRP, BTB, LSQ, Storg, Cdbus):
        resaddi = self.helpcalculatAddi(self.addi, ROB, RAT, BRP, BTB, LSQ, Cdbus)
        resaddd = self.helpcalculatAddd(self.addd)
        resmult = self.helpcalculatMult(self.mult)
        reslsqu = self.helpcalculatLsqu(self.lsqu, LSQ, Storg, ROB)
        return [resaddi, resaddd, resmult, reslsqu]
    
    def clear_mis(self, index, Cdbus):
        for item in self.addi:
            if item[0] == True:
                if item[5] > index:
                    item[0] = False
                    item[1:] = ["empty"] * 8
        for item in self.addd :
            if item[0] == True:
                
                if item[5] > index and item[0] == True:
                    item[0] = False
                    item[1:] = ["empty"] * 8
        for item in self.mult:
            if item[0] == True:
                if item[5] > index and item[0] == True:
                    item[0] = False
                    item[1:] = ["empty"] * 8
        for item in self.lsqu :
            if item[0] == True:
                
                if item[5] > index and item[0] == True:
                    item[0] = False
                    item[1:] = ["empty"] * 8
        for item in Cdbus.requestlst:
            if item != False:
                aaa = item.split()
                if aaa[3] > index:
                    index = Cdbus.requestlst.index(item)
                    Cdbus.requestlst[index] = False
    
    def clear(self, busdata, LSQ):
        for item in busdata:
            itemsp = item.split(" ")[0]
            if "addi" in itemsp:
                self.addi[int(itemsp[4:])][0] = False
                self.addi[int(itemsp[4:])][1:] = ["empty"] * 6
            elif "beq" in itemsp:
                self.addi[int(itemsp[3:])][0] = False
                self.addi[int(itemsp[3:])][1:] = ["empty"] * 6
            elif "bne" in itemsp:
                self.addi[int(itemsp[3:])][0] = False
                self.addi[int(itemsp[3:])][1:] = ["empty"] * 6
            elif "addd" in itemsp:
                self.addd[int(itemsp[4:])][0] = False
                self.addd[int(itemsp[4:])][1:] = ["empty"] * 6
            elif "mult" in itemsp:
                self.mult[int(itemsp[4:])][0] = False
                self.mult[int(itemsp[4:])][1:] = ["empty"] * 6
            elif "ldqu" in itemsp:
                LSQ.clearLSQ(self.lsqu[int(itemsp[4:])][5], self.lsqu[int(itemsp[4:])][6])
                self.lsqu[int(itemsp[4:])][0] = False
                self.lsqu[int(itemsp[4:])][1:] = ["empty"] *  6

            elif "sdqu" in itemsp:
                self.lsqu[int(itemsp[4:])][0] = False
                self.lsqu[int(itemsp[4:])][1:] = ["empty"] * 6
    def misprediction_check(self, op_type, offset, cal_result, index, ROB, RAT, BRP, BTB, PC, LSQ, Cdbus):
        if op_type == 'bne':
            if cal_result == 0:
               jump = 0
               address = 0
            else:
                jump = 1
                address = offset
        else:
            if cal_result ==0:
                jump = 1
                address = offset
            else:
                jump = 0
                address = 0
        result = ROB.readROB(index)
        result_jump = result[1]
        result_addr = result[2]
        if result_jump != jump :
            return 1
        else:
            
            if result_jump == 1:
                if result_addr != address:
                    return 1
    
    def misprediction(self, op_type, offset, cal_result, index, ROB, RAT, BRP, BTB, PC, LSQ, Cdbus):
        print("go to misprediction function")
        if op_type == 'bne':
            if cal_result == 0:
                jump = 0
                address = 0
            else:
                jump = 1
                address = offset

        else: 
            if op_type == 'beq':
                if cal_result == 0:
                    jump = 1
                    address = offset
                else:
                    jump = 0
                    address = 0

        result= ROB.readROB(index)
        result_jump = result[1]
        result_addr = result[2]
    
        if result_jump != jump :
            self.PC_next = self.helpmispredict(jump, address, index, ROB,RAT, BRP, BTB, PC, LSQ, Cdbus)
            self.mis_pre = 1
        else:
            if result_jump == 1:
                if result_addr != address :
                    self.PC_next = self.helpmispredict(jump, address, index, ROB, RAT, BRP, BTB, PC, LSQ, Cdbus)
                    self.mis_pre = 1
        ROB.ROB[index][3] = True
        return PC 

    
    def helpmispredict(self, jump, address, index, ROB, RAT, BRP, BTB, PC, LSQ, Cdbus):
        print("go to help misprediction")
        self.clear_mis(index, Cdbus)
        ROB.flushROB(index)
        RAT.recoverRAT(index)
        ROB.updateROB(index, address)
        BRP.updateBRP(PC//4, jump)
        BTB.updateBTB(PC//4%8, address)
        LSQ.flushLSQ(index)
        PC = PC + 4 + address * 4

        return PC
########add by yanan########

def misprediction(op_type, offset, cal_result, index, ROB, RAT, BRP, BTB, PC):
    # print("go to misprediction function")
    if op_type == 'bne':
        if cal_result == 0:
            jump = 0
            address = 0
        else:
            jump = 1
            address = offset

    else: 
        if op_type == 'beq':
            if cal_result == 0:
                jump = 1
                address = offset
            else:
                jump = 0
                address = 0

    result= ROB.readROB(index)
    result_jump = result[1]
    result_addr = result[2]
    
    if result_jump != jump :
        PC = helpmispredict(jump, address, index, ROB,RAT, BRP, BTB, PC)

    else:
        if result_jump == 1:
            if result_addr != address :
                PC = helpmispredict(jump, address, index, ROB, RAT, BRP, BTB, PC)
    return PC 


def helpmispredict(jump, address, index, ROB, RAT, BRP, BTB, PC):
    Funit.clear(index)
    ROB.flushROB(index)
    RAT.recoverRAT(index)
    ROB.updateROB(index, address)
    BRP.updateBRP(PC//4, jump)
    BTB.updateBTB(PC//4%8, address)
    PC = PC + 4 + address * 4

    return PC


class CDBstruct(object): #CDB unit
    def __init__(self, busdata):
        self.busdata = ["empty"] * busdata
        self.announcelst = []
        self.requestlst = [False, False, False, False]
    def __repr__(self):
        allFU = "busdata is:" + str(self.busdata) + "\n" + \
                "announcelst is:" + str(self.announcelst) + "\n" + \
                "requestlst is:" + str(self.requestlst) + "\n"
        return allFU
    def arbit(self):
        for i in range(len(self.busdata)):
            indexlst = []
            for item in self.requestlst:
                if item != False:
                    rs = item.split(" ")[0]
                    indexlst.append(self.announcelst.index(rs))
            if indexlst != []:
                minIndex = min(indexlst)
                for j in range(len(self.requestlst)):
                    if self.requestlst[j] != False and (
                    self.announcelst[minIndex] in self.requestlst[j]):
                        self.busdata[i] = self.requestlst[j]
                        self.announcelst.pop(minIndex)
                        self.requestlst[j] = False
                        break
            # else: self.busdata = ["empty"] * len(self.busdata)
        return self.busdata
    def clear(self):
        self.busdata = ["empty"] * len(self.busdata)




########### add by yanan--

class RATstruct(object):
    def __init__(self, RAT_Size_f, RAT_Size_in, ini_f, ini_in):
        self.size_f = RAT_Size_f
        self.size_in = RAT_Size_in
        self.RAT_f = [(["empty"]) for row in range(self.size_f)]
        self.RAT_in = [(["empty"]) for row in range(self.size_in)]
        self.RAT_f_copy = [0] * 100
        self.RAT_in_copy = [0] * 100
        for m in range(0, self.size_f):
            self.RAT_f[m] = ['F']
            self.RAT_f[m].append(m)
        for n in range(0, self.size_in):
            self.RAT_in[n] = ['R']
            self.RAT_in[n].append(n)
        for i in range(0, len(ini_f), 2):
            self.RAT_f[ini_f[i]] = ['ROB']
            self.RAT_f[ini_f[i]].append(ini_f[i+1])
        for j in range(0, len(ini_in), 2):
            self.RAT_in[ini_in[j]] = ['ROB']
            self.RAT_in[ini_in[j]].append(ini_in[j+1])


    def updateRAT(self, Regtype, Regnumb, UpdValue):
        if Regtype == 'F':
            self.RAT_f[Regnumb] = UpdValue
        else:
            self.RAT_in[Regnumb] = UpdValue

    def readRAT(self, Regtype, Regnumb):
        if Regtype == 'F':
            return_value = self.RAT_f[Regnumb]
        else:
            return_value = self.RAT_in[Regnumb]
        
        return return_value
    def copyRAT(self, index):
        self.RAT_in_copy[index] = copy.copy(self.RAT_in)
        self.RAT_f_copy[index] = copy.copy(self.RAT_f)

    def recoverRAT(self, index):
        self.RAT_in = copy.copy(self.RAT_in_copy[index])
        self.RAT_f = copy.copy(self.RAT_f_copy[index])

class ROBstruct(object):
    def __init__(self, ROB_Size):
        self.headSP = 0
        self.tailSP = -1	
        self.size = ROB_Size
        self.ROB = [([False] + ["empty"] + [0] + [False] + ["empty"] + ["empty"]) for row in range(self.size)]
        self.ROB_copy =[[0] * 10] 

    def addROB(self, DesRegister, op_type, PC):
        self.tailSP = self.tailSP + 1
        self.ROB[self.tailSP] = [True] + [DesRegister] + [0] + [False] + [op_type] +[PC]
        return self.tailSP
    
    def updateROB(self, ROBNumber, DesResult):
        self.ROB[ROBNumber][2] = DesResult
        self.ROB[ROBNumber][3] = True
        
    def updateROB_sd(self, ROBNumber, DesResult, Address):
        self.ROB[ROBNumber][1] = DesResult
        self.ROB[ROBNumber][2] = Address
        self.ROB[ROBNumber][3] = True

    def updateROB_branch(self, index, jump, jump_addr):
        self.ROB[index][1] = jump
        self.ROB[index][2] = jump_addr



    def readROB(self, ROBNumber):
        return self.ROB[ROBNumber]

    def flushROB(self, index):
        for row in range(index + 1, self.size):
            self.ROB[row] = [False] +["empty"] + [0] + [False] + ["empty"] + ["empty"]
        self.tailSP = index

    def commitROB(self, Storg, LSQ, memcyc):
        if self.ROB[self.headSP][3] == True :
            if self.ROB[self.headSP][4] == 'sd':
                print("go into check1")
                for item in LSQ.LSQ:
                    
                    if item[9] == self.headSP and item[0] == True:
                        index = LSQ.LSQ.index(item)
                        if item[1] == False:
                            print("go into check2")
                            return_value = LSQ.sdLSQ(index, memcyc)
                            if return_value == True:
                                self.ROB[self.headSP][0] = False
                                self.headSP = self.headSP + 1
                                return self.ROB[self.headSP - 1][5],self.headSP
                            else :
                                return False, False
                        else:
                            return_value2 = LSQ.checksdLSQ(index, memcyc)
                            if return_value2 == True:
                                self.ROB[self.headSP][0] = False
                                self.headSP = self.headSP + 1
                                return self.ROB[self.headSP - 1][5],self.headSP
                            else:
                                return False, False
            else:
                if self.ROB[self.headSP][4] == 'bne' or self.ROB[self.headSP][4] == 'beq':
                    self.ROB[self.headSP][0] = False
                    self.headSP = self.headSP + 1
                else:
                    if self.ROB[self.headSP][4] == 'add' or self.ROB[self.headSP][4] == 'sub' or self.ROB[self.headSP][4] == 'addi':
                        Storg.inRReg[int(self.ROB[self.headSP][1][1:])] = int(self.ROB[self.headSP][2])
                    
                        self.ROB[self.headSP][0] = False
                        self.headSP = self.headSP + 1
                        

                    else:
                        Storg.flFReg[int(self.ROB[self.headSP][1][1:])] = float(self.ROB[self.headSP][2])
                        self.ROB[self.headSP][0] = False
                        self.headSP = self.headSP + 1
            return self.ROB[self.headSP - 1][5], self.headSP
        return False, False

class BTBstruct(object):
    def __init__ (self):
        self.BTB_Size = 8
        self.BTB = [0 for row in range(self.BTB_Size)]
    
    def searchBTB(self, index):
        return self.BTB[index]

    def updateBTB(self, index, updateValue):
        if(index < self.BTB_Size):
            self.BTB[index] = updateValue
            return True
        else:
            return False

# set the number of BRP entry to 20 by hand #####
class BRPstruct(object):
    def __init__ (self):
        self.BRP_Size = 20
        self.BRP = [0 for row in range(self.BRP_Size)]
    
    def searchBRP(self, index):
        return self.BRP[index]

    def updateBRP(self, index, updateValue):
        if(index < self.BRP_Size):
            self.BRP[index] = updateValue
            return True
        else:
            return False

class LSQstruct(object):
    def __init__(self, LSQ_Size):
        self.LSQ = [([False] + [False] + ["empty"] + [0] + ["empty"] + [0] + [0]
            + [False] + [0] + [0]) for row in range(LSQ_Size)]
        self.headSP = 0
        self.tailSP = -1
        self.busyflag = 0

    def addLSQ(self, destination, address, op_type, PC, ROB_Index, ROB, memcyc):
        self.tailSP = self.tailSP + 1
        self.LSQ[self.tailSP] = [True] + [False] + [destination] + [address] + [op_type] + [0] + [0] + [False] + [PC] + [ROB_Index]
        if 'sd' in op_type: 
            self.LSQ[self.tailSP][5] = destination
            ROB.updateROB_sd(int(ROB_Index), float(destination), int(address))
        flag = 0
        if 'ld' in op_type and self.tailSP > self.headSP:
            
            for index in range(self.tailSP -1, self.headSP-1, -1):
                if self.LSQ[index][3] == address and 'sd' in self.LSQ[index][4] and self.LSQ[index][0] == True:
                    self.LSQ[self.tailSP][5] = self.LSQ[index][5]
                    self.LSQ[self.tailSP][7] = True
                    self.LSQ[self.tailSP][6] = 2
                    self.LSQ[self.tailSP][1] = True
                    flag = 1
                    break

            
        if flag == 0:
            if self.tailSP > self.headSP and 'ld' in op_type :
                    
                for index in range(self.tailSP - 1, self.headSP -1, -1):
                    if self.LSQ[index][7] == False and self.LSQ[index][0] == True and self.LSQ[index][1] == True:
                        self.LSQ[self.tailSP][6] = self.LSQ[index][6] + memcyc
                        self.LSQ[self.tailSP][1] = True
                        flag = 1
                        break
                if flag == 0:
                    self.LSQ[self.tailSP][6] = memcyc + 2
                    self.LSQ[self.tailSP][1] = True
            elif 'ld' in op_type:
                self.LSQ[self.tailSP][6] = memcyc + 2
                self.LSQ[self.tailSP][1] = True
            self.busflag = 1


    def exeLSQ(self, Storg):
        for item in self.LSQ:
            if item[0] == True and item[1] == True and item[6] != 0:
                item[6] = item[6] - 1
        
        for item2 in self.LSQ:
            if item2[6] == 0 and item2[0] == True and item2[1] == True and 'sd' in item2[4]:
                Storg.mainMem[item2[3]] = item2[2]
                item2[6] = True
                item2[0] = False
                break
        for item1 in self.LSQ:
            if item1[6] == 0 and item1[0] == True and item1[1] == True and 'ld' in item1[4]:
                item1[5] = Storg.mainMem[int(item1[3])]         #xin4
                return item1[4] + " " + str(item1[2]) + " " + str(item1[5]) + " " + str(item1[9]) + " " + str(item1[8])
        return False
    
    def clearLSQ(self, ROB_Index, PC):
        for item in self.LSQ:
            if item[9] == ROB_Index and item[8] == PC:
                item[0] = False
    
    def sdLSQ(self, sd_index, memcyc):
        flag = 0
        if self.tailSP >= self.headSP :
            print("go into check3") 
           
            for index in range(self.tailSP, self.headSP - 1, -1):
                if self.LSQ[index][7] == False and self.LSQ[index][0] == True and self.LSQ[index][1] == True:
                    self.LSQ[sd_index][6] = self.LSQ[index][6] + memcyc
                    self.LSQ[sd_index][1] = True
                    flag = 1
                    return False
            if flag == 0:
                self.LSQ[sd_index][6] = memcyc
                self.LSQ[sd_index][1] = True
                return True

        else:
            self.LSQ[sd_index][6] = memcyc
            self.LSQ[sd_index][1] = True
            return True
    def checksdLSQ(self, sd_index, memcyc):
        if self.LSQ[sd_index][6] == memcyc:
            return True
        return False

    def flushLSQ(self, ROB_Index):
        for item in self.LSQ:
            if item[9] > ROB_Index:
                item[0] = False
            

class CYCstruct(object): #Cycle structure, serve as goble variation
    def __init__(self, clock, insSize):
        self.clock = clock
        self.ctabl = [(["-"]*5) for row in range(insSize)] 
        self.recordlst1 = []
        self.recordlst2 = []
        self.recordlst3 = []
        self.newappend1 = ["empty", 0]
        self.newappend2 = ["empty", 0]
        self.newappend23 = ["empty", 0]
        self.newappend3 = ["empty", 0]
        self.sel = 2
        self.ctabl2 = [(["-"]*5) for row in range(insSize)] 
        self.insMem2 = []

######This is high level functions part            
def statTranfunc(state): #maybe unuseful
    if state[0] == "IDLE": state[0] = "ENTR"
    elif state[0] == "ENTR": state[0] = "FULL"
    elif state[0] == "FULL": state[0] = "EXIT"
    elif state[0] == "EXIT": state[0] = "IDLE"
    else: state[0] = "ERRO"
        
def pipfunc(Storg, Funit, Cdbus, Cycles, ROB, RAT, BRP, BTB, LSQ):
    # initial
    state = ["IDLE"]
    flag = 0
    clock = 0
    cnt = 4
    (ISU, EXU, MEM, WBK, CMT) = ([0,0,0,0,0,0,0], [0,['empty']], 
        [0, "empty", "empty"], [0, "empty", "empty"], [0, "empty", "empty"]) 
    MEM2WBK = [0]
    while(1):
        flag = flag + 1
        print("########", flag, "#######")
        # clock part
        clock = clock + 1
        Cycles.clock = clock            
        
        # if Cycles.ctabl[len(Storg.insMem)-1][-1] != Cycles.olddata:
        #     Cycles.olddata = Cycles.ctabl[len(Storg.insMem)-1][-1]
        #     Cycles.ctablconti.append(copy.deepcopy(Cycles.ctabl))
            
        if Cycles.clock >= 80:
            break
        CMT2ISU = copy.deepcopy(CMT)
        CMT = cmtfunc(Storg, Cdbus, Funit, state, Cycles, ROB, LSQ)
        
        # wbk stage
        WBK = wbkfunc(Storg, Cdbus, EXU, state, Cycles, ROB, Funit)
        
        # execute stage
        EXU = exufunc(Storg, Funit, Cdbus, ISU, state, Cycles, ROB, RAT, BRP, BTB, LSQ)
        
        # issue stage
        if Funit.mis_pre == 1:
            Funit.mis_pre = 1
            ISU = [0, ["empty"]]
        else:
            ISU = isufunc(Storg, Funit, ISU, state, Cycles, ROB, RAT,
                BRP, BTB, Cdbus)
        
        print(ISU, " ","current testing ISSUE")
        print(EXU, " ", "current testing EXE")
        if Funit.mis_pre == 1:
            ISU[0] = EXU[0]
            Funit.mis_pre = 0


######This is readwrite part
def readCase(path):
    part = 0
    insMem = []
    (inRinit, flFinit, Meminit) = ([], [], [])
    CDBnum = 1
    for line in open(path).readlines():
        line = line.strip("\t")
        line = line.strip()
        if line.startswith("#"):
            continue
        if not len(line):
            part += 1
            continue
        if part == 0:
            numlst = []
            for word in line.split("\t"):
                if word.isdigit():
                    numlst.append(int(word))
                elif word == "":
                    numlst.append(0)
            if "Integer adder" in line:     inAddlst = copy.deepcopy(numlst)
            elif "FP adder" in line:        flAddlst = copy.deepcopy(numlst)
            elif "FP multiplier" in line:   flMullst = copy.deepcopy(numlst)
            elif "Load/store unit" in line: lsUnilst = copy.deepcopy(numlst)
        elif part == 1:
            (ROBflg, CDBflg) = (False, False)
            (Rflg, Fflg, Mflg) = (False, False, False)
            line = line.replace("=", ",")
            for word in line.split(","):
                word = word.strip()
                if word[0].isdigit():
                    if ROBflg:   ROBnum = int(word)
                    elif CDBflg: CDBnum = int(word)
                    elif Rflg: inRinit.append(int(word)); Rflg = False
                    elif Fflg: flFinit.append(float(word)); Fflg = False
                    elif Mflg: Meminit.append(float(word)); Mflg = False
                    else: num = int(word)
                if word.startswith("-"):
                    if Rflg: inRinit.append(-int(word[1:])); Rflg = False
                    elif Fflg: flFinit.append(-float(word[1:])); Fflg = False
                    elif Mflg: Meminit.append(-float(word[1:])); Mflg = False
                    else: num = -int(word[1:])
                if word.startswith("ROB"):
                    ROBflg = True
                elif word.startswith("CDB"):
                    CDBflg = True
                elif word.startswith("R"):
                    inRinit.append(int(word[1:])); Rflg = True
                elif word.startswith("F"):
                    flFinit.append(int(word[1:])); Fflg = True
                elif word.startswith("Me"):
                    Meminit.append(int(word[4:].strip("]"))); Mflg = True
                else: continue
        else:
            insMem.append(line)

    return inAddlst, flAddlst, flMullst, lsUnilst, ROBnum, CDBnum, inRinit, \
            flFinit, Meminit, insMem
            
def createReport(path, Storg, Cycles):
    #output Cycles
    if Cycles.sel == 1:
        content = "\t\t\tISSUE\tEX\tMEM\tWB\tCOMMIT\n"
        for i in range(len(Storg.insMem)):
            content += Storg.insMem[i] + " "*(24-len(Storg.insMem[i]))
            for c in Cycles.ctabl[i]:
                content += c + "\t"
            content  += "\n"
        content += "\n"
    else:
        content = "\t\t\tISSUE\tEX\tMEM\tWB\tCOMMIT\n"
        for i in range(len(Cycles.insMem2)):
            content += Cycles.insMem2[i] + " "*(24-len(Cycles.insMem2[i]))
            for c in Cycles.ctabl2[i]:
                content += c + "\t"
            content  += "\n"
        content += "\n"
    #debug, could be deleted
    # for i in range(len(Storg.insMem), len(Storg.insMem) +3):
    #     content += "******************\t"
    #     for c in Cycles.ctabl[i]:
    #         content += c + "\t"
    #     content  += "\n"
    # content += "\n"
    #output REGISTER VALUES
    content += "REGISTER VALUES\n\t"
    for j in range(4):
        for i in range(j*8, (j+1)*8):
            content += "R"+ str(i) + "\t"
        content += "\nvalue:\t"
        for i in range(j*8, (j+1)*8):
            content += str(Storg.inRReg[i]) + "\t"
        content += "\n\t"
    for j in range(4):
        for i in range(j*8, (j+1)*8):
            content += "F"+ str(i) + "\t"
        content += "\nvalue:\t"
        for i in range(j*8, (j+1)*8):
            roundflFReg = round(Storg.flFReg[i], 2)
            content += str(roundflFReg) + "\t"
        content += "\n\t"  
    content += "\n"
    #output NON-ZERO MEMORY VALUES
    content += "\nNON-ZERO MEMORY VALUES\n"
    content += "Addr\tValues\n"
    for i in range(0,len(Storg.mainMem)):
        if Storg.mainMem[i] != 0:
            roundmainMem = round(Storg.mainMem[i], 2)
            content += str(i)+"\t"+str(roundmainMem)+"\n"
    with open(path, "wt") as f:
        f.write(content.expandtabs(tabsize=8))
    print(content.expandtabs(tabsize=8))

######This is test part    
def testfunc():
    print("******")
    print("this is the whole test function")
    
    # prepare config 
    (inAddlst, flAddlst, flMullst, lsUnilst, ROBnum, CDBnum, inRinit, flFinit,
     Meminit, insMem) = readCase("testCase.txt")
    Storg = STstruct(insMem, inRinit, flFinit, Meminit)
    Funit = FUstruct(inAddlst[0], flAddlst[0], flMullst[0], lsUnilst[0],
                     inAddlst[1], flAddlst[1], flMullst[1], lsUnilst[1],
                     lsUnilst[2])
    Cdbus = CDBstruct(CDBnum)
    Cycles = CYCstruct(0,len(Storg.insMem)+80)
    
    ROB_Size = 100
    ROB = ROBstruct(ROB_Size)
    RAT = RATstruct(32, 32, [], [])
    BTB = BTBstruct()
    BRP = BRPstruct()
    aaa = BRP.updateBRP(0, 0)
    bbb = BTB.updateBTB(0, 0)
    LSQ = LSQstruct(20)  
    
    # execute in pipeline
    pipfunc(Storg, Funit, Cdbus, Cycles, ROB, RAT, BRP, BTB, LSQ)
    # create report
    createReport("report.txt", Storg, Cycles)
    
    print("******")
    print("finish")

def main():
    testfunc()

if __name__ == '__main__':
    main()  
    
